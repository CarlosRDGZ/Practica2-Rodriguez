<hr />
<footer>
    <center>
        &copy; Direcci&oacute;n de Sistemas - Derechos Reservados 
	</center>
</footer>


</body>

</html>